package com.talhachaudhry.jpharmaappfyp.callbacks;

import com.talhachaudhry.jpharmaappfyp.models.CartModel;

public interface CartCallback {

    void onDeleteClicked(CartModel model);
}
