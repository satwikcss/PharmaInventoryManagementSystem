package com.talhachaudhry.jpharmaappfyp.callbacks;

public interface OnItemClicked {
    void setOnItemClicked(String itemName, int position);
}
