package com.talhachaudhry.jpharmaappfyp.callbacks;

import com.talhachaudhry.jpharmaappfyp.models.UserModel;

public interface OnViewWholesalerClicked {
    void  onViewWholesalerClicked(UserModel model);
}
